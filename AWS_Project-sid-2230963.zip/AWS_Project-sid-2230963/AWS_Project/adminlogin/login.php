<?php
include("connection.php");
if(isset($_POST['submit'])){
$gmail = $_POST['user'];
$password = $_POST['pass'];
$sql="select * from client where gmail = '$gmail' and password = '$password'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$count = mysqli_num_rows($result);
if($count==1){
    header("Location:/adminhomepage/show.php");
}
else{
    echo '<script>
    window.location.href = "index.php";
    alert("Login failed. invalid username or password")
    </script>';
}
}
?>